package com.cg.banking.exceptionAspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InvalidAmountException;


@ControllerAdvice
public class BankingExceptionAspect {
	@ExceptionHandler(InvalidAmountException.class)
	public ModelAndView handelAssociateDetailsNotFoundException(Exception e)
	{
		return new ModelAndView("findAccountDetailsPage","errorMessage",e.getMessage());
	}
	@ExceptionHandler(AccountNotFoundException.class)
	public ModelAndView handelAccountNotFoundException(Exception e)
	{
		return new ModelAndView("depositMoney","errorMessage",e.getMessage());
	}

}
