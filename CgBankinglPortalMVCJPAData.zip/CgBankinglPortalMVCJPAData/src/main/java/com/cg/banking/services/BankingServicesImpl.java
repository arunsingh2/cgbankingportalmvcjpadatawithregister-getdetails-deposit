package com.cg.banking.services;
import java.util.HashMap;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;

import com.cg.banking.daoservices.TransactionDAO;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@Component("services")
public class BankingServicesImpl implements BankingServices {
	@Autowired
public AccountDAO daoImpl;
	@Autowired
	public TransactionDAO tDaoImpl;
	Transaction transaction;
	Transaction transaction1;
	Account account;
	Account account1;
	public static HashMap<Integer,Transaction> transactions;
	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if(account.getAccountBalance()<500) {
            throw new InvalidAmountException("enter amount above 500");
        }
		return daoImpl.save(account);
	}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException {
		Account account=daoImpl.findById((long) accountNo).orElseThrow(()->new AccountNotFoundException("account not found"+accountNo));
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		
		else{
			account.setAccountBalance(account.getAccountBalance()+amount);
			daoImpl.save(account);
			transaction=new Transaction(amount,"Deposit",account);
			transaction=tDaoImpl.save(transaction);
		}
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) 
			throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		account=daoImpl.findById((long) accountNo).orElseThrow(()->new BankingServicesDownException("account not found"+accountNo));
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		if(account.getPinNumber()==pinNumber){
			if(amount>account.getAccountBalance())
				throw new InsufficientAmountException();
			else{
				account.setAccountBalance(account.getAccountBalance()-amount);
				transaction=new Transaction(amount,"Withdraw",account);
				tDaoImpl.save(transaction);
				daoImpl.save(account);
			}
		}
		else {
			throw new InvalidPinNumberException();
		}
		return account.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		int c=3;
		do {
			account=daoImpl.findById((long) accountNoFrom).orElseThrow(()->new BankingServicesDownException("account not found"+accountNoFrom));
			account1=daoImpl.findById((long) accountNoTo).orElseThrow(()->new BankingServicesDownException("account not found"+accountNoTo));
			if(account==null || account1==null)
			{
				throw new AccountNotFoundException("Please enter valid account number");
			}
			else {
				if(account.getPinNumber()==pinNumber){
					if(transferAmount>account.getAccountBalance())
						throw new InsufficientAmountException("Insufficient balance in your account");
					else
						account.setAccountBalance(account.getAccountBalance()-transferAmount);
					account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
					transaction=new Transaction(transferAmount,"Withdraw",account);
					transaction1=new Transaction(transferAmount,"Deposit",account1);
					tDaoImpl.save(transaction);
					tDaoImpl.save(transaction1);
					daoImpl.save(account);
					daoImpl.save(account1);
				}
				else
				{
					c--;
					throw new InvalidPinNumberException();   }
			} 
		}
		while(account.getPinNumber()!=pinNumber);
		return true;
	}
	@Override
	public Account getAccountDetails(long accountNo) throws BankingServicesDownException, AccountNotFoundException {
		account= daoImpl.findById((long) accountNo).orElseThrow(()->new BankingServicesDownException("account not found"+accountNo));
		if(account==null)
			throw new AccountNotFoundException("No Account found");
		return account;
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) 
			throws BankingServicesDownException, AccountNotFoundException {
		return tDaoImpl.findAll();
	}
	@Override
	public String accountStatus(long accountNo) 
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account= daoImpl.findById((long) accountNo).orElseThrow(()->new BankingServicesDownException("account not found"+accountNo));
		return account.getAccountStatus();
	}
	@Override
	public void checkPin(int counter, long accountNo) throws AccountBlockedException {
		if(counter==0) {
			account.setAccountStatus("Blocked");
			daoImpl.save(account);
			throw new AccountBlockedException();
		}
	}
}
