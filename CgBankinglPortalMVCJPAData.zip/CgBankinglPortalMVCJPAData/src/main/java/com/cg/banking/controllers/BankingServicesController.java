package com.cg.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;


@Controller
public class BankingServicesController {
	
	@Autowired
	BankingServices services;
		@RequestMapping("/openAccount")
	public ModelAndView registerAccount(@ModelAttribute Account account) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		account=services.openAccount(account);
		return new ModelAndView("registrationSuccessPage","account",account);
}
		@RequestMapping("/accountDetails")
		public ModelAndView registerAccount(@RequestParam int accountNo)throws AccountNotFoundException, BankingServicesDownException{
			Account account=services.getAccountDetails(accountNo);
			return new ModelAndView("findAccountDetailsPage","account",account);
	}
		@RequestMapping("/depositMon")
		public ModelAndView depositAccount(@RequestParam int accountNo, float amount)throws AccountNotFoundException{
		float deposit=services.depositAmount(accountNo,amount);
		return new ModelAndView("depositSuccessPage","deposit",deposit);
			
	}
		@RequestMapping("/withdrawMon")
		public ModelAndView withdrawAccount(@RequestParam int accountNo, float amount,int pinNumber)throws AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		float deposit=services.withdrawAmount(accountNo,amount,pinNumber);
		return new ModelAndView("depositSuccessPage","deposit",deposit);
			
	}
}
//@Controller
//@RequestMapping(value = "/employee")
//public class EmployeeController {
//    @RequestMapping(value = "/display/{empId}/{empName}")
//    public ModelAndView showEmployeeForm(@PathVariable String empId, @PathVariable String empName) {
//                // Some Business Logic
//    } 
//}